# GapBench-Natural v1.0 Draft

This package contains 200 naturalized GapBench examples for human review.

Audit status:

- `gapbench_natural_200_for_review.jsonl` is not yet human-audited.
- The labels are inherited from human-audited GapBench v1.0 source tasks.
- The user-facing queries were naturalized and should be reviewed before final paper claims.
- A deterministic cleanup pass removed templated benchmark remnants such as artificial case labels, placeholder product names, and sandbox filename artifacts from the visible user queries.

Composition:

- 40 pure/direct language tasks
- 40 observation/evidence tasks
- 30 execution/computation tasks
- 30 file/workspace inspection tasks
- 20 sandbox action/permission tasks
- 20 ambiguous/unsupported tasks
- 20 mixed multi-obligation tasks

Use this dataset to test whether the obligation calculus transfers beyond templated controlled queries.
